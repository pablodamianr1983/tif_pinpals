document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        document.querySelector('.container').classList.add('visible');
    }, 2100); 
});

